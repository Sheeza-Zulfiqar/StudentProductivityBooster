<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title> Navigation Bar</title>

  <link rel="stylesheet" href="styles.css">
	<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
	<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script>
		$(document).ready(function(){
			$(".hamburger").click(function(){
			   $(".wrapper").toggleClass("collapse");
			});
		});
	</script>
</head>
<body>

<div class="wrapper">
  <div class="top_navbar">
    <div class="hamburger">
       <div class="one"></div>
       <div class="two"></div>
       <div class="three"></div>
    </div>
    <div class="top_menu">
      <div class="logo">Smart Education System</div>
      <ul>
       
        <li><a href="Home.html">
          <i class="fas fa-user" aria-hidden="true"></i>
          </a></li>
      </ul>
    </div>
  </div>
  
  <div class="sidebar">
      <ul>
        <li><a href="#">
          <span class="icon"><i class="fas fa-book"></i></span>
          <span class="title">Assignments</span></a></li>
        <li><a href="#">
          <span class="icon"><i class="fas fa-file"></i></span>
          <span class="title">Reports</span>
          </a></li>
        <li><a href="#time">
          <span class="icon"><i class="fa fa-calendar"></i></span>
          <span class="title">Time Table</span>
          </a></li>
        
    </ul>
  </div>
  
  <div class="main_container">
    
  </div>
  <div id="time">
    <h1>Hello</h1>
    <?php include 'getTable.php';?>
    
  </div>
</div>
	
</body>
</html>