<?php
session_start();
// Change this to your connection info.
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = '';
$DATABASE_NAME = 'fyp';
// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if ( mysqli_connect_errno() ) {
	// If there is an error with the connection, stop the script and display the error.
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}
if (isset($_POST['btnn']))
{
    $email = trim($_POST['email']);  
    // echo $email;
    $password = trim($_POST['password']);  
      
        //to prevent from mysqli injection  
        $email = stripcslashes($email);  
        $password = stripcslashes($password);  
        $email = mysqli_real_escape_string($con, $email);  
        $password = mysqli_real_escape_string($con, $password);  
      
        $sql = "select email,password from signup where email = '$email' and password = '$password'";  
        $result = mysqli_query($con, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result); 
       //echo $row;
      //  echo $count; 
          
        if($count == 1){  
            echo '<script language="javascript">';
            echo 'alert("Login Successfully")';
            echo '</script>';
            echo "<script> window.location.assign('role.php'); </script>";
        }  
        else{  
            echo '<script language="javascript">';
            echo 'alert("Login Failed")';
            echo '</script>';
        } 
      }
      // if (isset($POST["back"])) 
      // {
      
      //   echo "<script> window.location.assign('index.html'); </script>";
        
      // }   
?>  
<!DOCTYPE html>
<html>
	<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	</head>
<style>

* {
  	box-sizing: border-box;
  	font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
  	font-size: 16px;
  	-webkit-font-smoothing: antialiased;
  	-moz-osx-font-smoothing: grayscale;
}
form{
    
    width:100%;
  }
 
.wrapper{
    height:100vh;
    width:100%;
    justify-content:center;
    background-color: darkcyan;
    /*background-image:url("./images/pic8.jpg");*/
    background-repeat:no-repeat;
    background-size:100%;
    align-items: center;
    display:flex;
    flex-direction:column;
  
  }
  .form-wrapper{
    width:500px;
    height:600px;
    display:flex;
    flex-direction:column;
    padding: 20px 40px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  #btnn
  {
    width:120px;
    margin-left:150px;
    margin-top:10px;
    display: flex;
    align-items: center;
    flex-direction:column;
    text:white;
  }
.login {
  	width: 400px;
  	background-color: #ffffff;
  	box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
  	margin: 100px auto;
}
.login h1 {
  	text-align: center;
  	color: #5b6574;
  	font-size: 24px;
  	padding: 20px 0 20px 0;
  	border-bottom: 1px solid #dee0e4;
}
input::placeholder{
    font-family: "Times New Roman", Times, serif;
  }
  h1{
  
  text-align: center;
  width:100%;
  color:blue;
  font-family: "Times New Roman", Times, serif;
}


#errormessage{
  font-family: "Times New Roman", Times, serif;
  font-size:15px;
  color:red;
}
#btnn2{
    width:120px;
    margin-left:150px;
    margin-top:10px;
    display: flex;
    align-items: center;
    flex-direction:column;
    text:white;
}
</style>
	<body>
		<div class="wrapper">
        <div class="form-wrapper">
			<h1>Login</h1>
			<form method="post" action="login1.php">
            <div  class="form-group">
				<label for="email">
				</label>
				<input type="email" name="email" placeholder="Email" id="email" required class='box'>
            </div>
            <div  class="form-group">
                <label for="password">
				</label>
				<input type="password" name="password" placeholder="Password" id="password" required class='box'>
            </div>
            <div  class="form-group">
				<input type="submit" value="Login" class="btn btn-outline-primary" name="btnn">
            </div>
            <div  class="form-group">
				<button type='submit' class="btn btn-outline-primary" name="back" ><a href="index.html">Back</a></button>

            </div>
            <div  class="form-group">
				<a href="sign2.php">Not registered yet?</a></button>
        
            </div>
			</form>
		</div>
        <script>  
            function validation()  
            {  
                var id=document.f1.user.value;  
                var ps=document.f1.pass.value;  
                if(id.length=="" && ps.length=="") {  
                    window.alert("User Name and Password fields are empty");  
                    return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        window.alert("User Name is empty");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    window.alert("Password field is empty");  
                    return false;  
                    }  
                }                             
            }  
        </script>  
	</body>
</html>