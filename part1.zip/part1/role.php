<?php
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link href="https://fonts.googleapis.com/css?family=Literata&display=swap" rel="stylesheet">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Home</title>
  
    <!-- Bootstrap -->
   <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">-->
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
     <meta charset="UTF-8">
	<title>Responsive Side Navigation Bar</title>
	<link rel="stylesheet" href="style.css">
	 <script src="https://kit.fontawesome.com/b99e675b6e.js"></script> 
	<!-- <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>  -->
	<script>
		$(document).ready(function(){
			$(".hamburger").click(function(){
			   $(".wrapper").toggleClass("collapse");
			});
		});
	</script>
     </head>
     
 <style>
     
  
   #style{
    font-family: "Times New Roman", Times, serif;
    height:70px;
    background-color:darkblue;
   }
   #errormessage{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:red;
    position:absolute;
    left:500px;
    bottom:420px;

 }   
   .rights{
    list-style-type: none;
    margin: 0;
    padding: 0;
    width: 200px;
    height:632px;
    background-color:darkblue;
   }
   
   #btn2
   {
     margin-left:0px;
     margin-right:20px;
     width:180px;
     margin-top:7px;
     border-radius:10px; 
     height:50px;
    /* border:1px solid darkblue;*/
     
   }
   #btn7
   {
     margin-left:0px;
    font-family: "Times New Roman", Times, serif;
    font-size: 20px;
    position:absolute;
    bottom:370px;
    left:800px;
    

   }
   Button a:hover {
  
    color:white;
  }
  

  #Sec
   {
    font-family: "Times New Roman", Times, serif;
    font-size: 25px;
    position:absolute;
    bottom:450px;
    left:300px;
   }   
  
  
#logo
{
  background-image:url("./images/images.jpg");
    background-repeat:no-repeat;
    background-size:65px;
    border:1px solid blue;
    position:absolute;
    top:10px;
    left:27px;
    width:67px;
    height:50px;

}
#logo1
{
  background-image:url("./images/download1.jpg");
    background-repeat:no-repeat;
    background-size:200px;
    border:1px solid white;
    position:absolute;
    top:70px;
    left:10px;
    width:200px;
    height:200px;

}

li a:hover{
  color:white;
}
.navbar-light{
    background-color:darkblue;
    color:white;
}
.brand-logo{
    font-size:30px;
}
#col{
    margin-right:10px;
    font-size: 20px;
}
#drop6{

font-family: "Times New Roman", Times, serif;
position:absolute;
bottom:450px;
left:500px;
width: 700px;
height:30px;}
 

</style>

  <body>
  <!-- <div>
  
        <nav class="navbar navbar-expand-sm  navbar-light" id="style">
            
            <div class="container">
            <span class="brand-logo">Smart Education System</span>
            
                <ul class="navbar-nav right">
                    
                    <li id="col"><a href="index.html">Logout</a></li>
                    
                </ul>
               
            </div>
            </nav> -->
            <div class="wrapper">
  <div class="top_navbar" href="#same">
    <div class="hamburger">
    <div class="one"></div>
       <div class="two"></div>
       <div class="three"></div>
    </div>
    <div class="top_menu" id ="same">
      <div class="logo">Smart Education System</div>
      <ul>
        
        <li><a href="index.html">
          <i class="fas fa-user">Logout</i>
          </a></li>
      </ul>
    </div>
  </div>
  
  <div class="sidebar">
      <ul>
        <li><a href="#">
          <span class="icon"><i class="fas fa-book"></i></span>
          <span class="title">Assignments</span></a></li>
        <li><a href="#">
          <span class="icon"><i class="fas fa-file-video"></i></span>
          <span class="title">Reports</span>
          </a></li>
        <li><a href="#">
          <span class="icon"><i class="fas fa-volleyball-ball"></i></span>
          <span class="title">Time Table</span>
          </a></li>
       
    </ul>
  </div>
  
  <div class="main_container">
    
  </div>
</div>
          
    
            

</div>  
<script>
		$(document).ready(function(){
			$(".hamburger").click(function(){
			   $(".wrapper").toggleClass("collapse");
			});
		});
	</script> 
  <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>  -->
  </body>
  </html>