<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: OPTIONS,GET,POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
$con=mysqli_connect("localhost","root","","fyp");
$response=array();
$res["Login"]=array();
if ($con){
    $sql='select * from signup';
    $result=mysqli_query($con,$sql);
    $i=0;
    
    if($result){
       
        header("Content-Type:JSON" );
        while($row=mysqli_fetch_assoc($result))
        {
            $response[$i]['id']=$row ['id'];
            $response[$i]['email']=$row ['email'];
            $response[$i]['password']=$row ['password'];
            // $response[$i]['regNo']=$row ['regNo'];
            // $response[$i]['email']=$row ['email'];
            $i++;
            array_push($res["Login"], $response);
        }
        echo http_response_code(200);
        echo json_encode($res);
        echo json_encode($response,JSON_PRETTY_PRINT);
        
        // echo "Heloo";
    }
    // else echo "Nahi ana";

}
else{
    echo http_response_code(404);
    echo "bYe";
}
?>