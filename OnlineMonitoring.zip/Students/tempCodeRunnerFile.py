            # schedule.every().day.tuesday.at("20:48").do(hello)
            # while True:
            #     schedule.run_pending()
                 