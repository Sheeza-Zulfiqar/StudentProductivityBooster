import cv2,time
import numpy as np 
import pyautogui 

import mysql.connector
MyDB=mysql.connector.connect( 
    host="localhost",
    user="root",
    password= "python" ,
    database="ImagesDb"
  
)
 
MyCursor=MyDB.cursor()
 
MyCursor.execute("CREATE TABLE IF NOT EXISTS TrainingData (id INTEGER(45) NOT NULL AUTO_INCREMENT PRIMARY KEY, Photo LONGBLOB NOT NULL)")
MyCursor.execute("CREATE TABLE IF NOT EXISTS CurrentScreenShots (id INTEGER(45) NOT NULL AUTO_INCREMENT PRIMARY KEY, Photo LONGBLOB NOT NULL)")

def InsertSS(FilePath):
    with open(FilePath, "rb") as File:
        binaryData=File.read()
    SQLStatement="INSERT INTO CurrentScreenShots (Photo) VALUES (%s)"
    MyCursor.execute(SQLStatement,(binaryData,))
    MyDB.commit()

def InsertTD(FilePath):
    with open(FilePath, "rb") as File:
        binaryData=File.read()
    SQLStatement="INSERT INTO TrainingData (Photo) VALUES (%s)"
    MyCursor.execute(SQLStatement,(binaryData,))
    MyDB.commit()




# Capturing real time video stream. 0 for built-in web-cams, 0 or -1 for external web-cams
video_capture = cv2.VideoCapture(0)
path="TrainingData"
path1="/"
P=path+path1   

path2="Screenshots"
path3="/"
P1=path2+path3   

end = time.time() + 60
i=0
while time.time() < end:
    
         
    print("monitering.....")
    image = pyautogui.screenshot() 
    image = cv2.cvtColor(np.array(image), 
                     cv2.COLOR_RGB2BGR) 


    # writing it to the disk using opencv 
    cv2.imwrite(P1+"SS{0}.jpg".format(int(time.time())), image)
    UserFilePath=P1+"SS{0}.jpg".format(int(time.time()))
    InsertSS(UserFilePath)
    print(UserFilePath)
 
        # Reading image from video stream
    _, img = video_capture.read()
 
    cv2.imwrite(P+ "img{0}.jpg".format(int(time.time())), img)
    UserFilePath1=P+"img{0}.jpg".format(int(time.time()))
 
    print(UserFilePath1)
    InsertTD(UserFilePath1)

        #cv2.imshow("face detection", img)
        # if cv2.waitKey(1) & 0xFF == ord('q'):
        #     break
 
    time.sleep(10 )
    i=i+1

 
print("endddddd")

# releasing web-cam
video_capture.release()
# Destroying output window
cv2.destroyAllWindows()  