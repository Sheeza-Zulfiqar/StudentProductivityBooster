import mysql.connector
import schedule,time
db_connection = mysql.connector.connect(host="localhost",user="root",password="python",database="student_db")
mycursor = db_connection.cursor()
#mycursor.execute("CREATE TABLE IF NOT EXISTS student_timeTable (std_id INTEGER(45) NOT NULL AUTO_INCREMENT PRIMARY KEY,day VARCHAR(255), startTime date,EndTime date")

mycursor.execute("select * from Subject_TimeTable")
my_data=mycursor.fetchall()
list=[]
for row in my_data:
    print(row[2])
    print(row[3])
    list.append((row[1],str(row[2]),str(row[3])))
print(list)


days=[]
strtTime=[]
def hello():
    print("hhhh")
for i in list:
    for y in i:
        days.append(i[0])
        if i[0]=='Tuesday':
            print("Tuesday",str(i[1]))
            schedule.every().day.tuesday.at(i[1]).do(hello)
            while True:
                schedule.run_pending()
                break
                 
   
        break
 