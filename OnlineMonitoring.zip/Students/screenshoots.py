import numpy as np 
import cv2 ,time
import pyautogui 
from registration  import *
   
time.sleep(10)  
# take screenshot using pyautogui 
image = pyautogui.screenshot() 
   
# since the pyautogui takes as a  
# PIL(pillow) and in RGB we need to  
# convert it to numpy array and BGR  
# so we can write it to the disk 
image = cv2.cvtColor(np.array(image), 
                     cv2.COLOR_RGB2BGR) 
path="Screenshots"
path1="/"
P=path+path1   

# writing it to the disk using opencv 
cv2.imwrite(P+"tryyyyy.png", image)