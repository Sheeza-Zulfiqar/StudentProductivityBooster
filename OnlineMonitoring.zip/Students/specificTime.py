# import sched, time

# def action():
#     print("strting.....")

# # Set up scheduler
# s = sched.scheduler(time.localtime, time.sleep)
# # Schedule when you want the action to occur
# s.enterabs(time.strptime('Mon Mar 15 9:35:07 2021'), 0, action)
# # Block until the action has been run
# s.run()

import schedule
import time

def job(t):
    print ("I'm working...", t)
    return

schedule.every().day.at("10:41").do(job,'It is 10:41')

while True:
    schedule.run_pending()
    time.sleep(60) # wait one minute