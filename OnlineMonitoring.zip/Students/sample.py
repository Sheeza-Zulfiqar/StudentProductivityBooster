import time

# end = time() + 20
# while time() < end:
#     # monitor keyboard input code
#     print("Hello")
# # print statement
# print("Bye")
 
# seconds = time.time()
# print("Seconds since epoch =", seconds)	
# print("This is printed immediately.")
# time.sleep(2.4)
# print("This is printed after 2.4 seconds.")

end = time.time() + 120
while time.time() < end:
         
    print("monitering.....")
    time.sleep(10 )

    # monitor keyboard input code

# print statementS
print("endddddd")

# print(time.time()%60)