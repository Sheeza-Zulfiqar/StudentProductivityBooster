<?php
include 'stddashboard.php';

?>
<!DOCTYPE html>
<html>
 <head>
 <!-- <link rel="stylesheet" href="styles.css"> -->
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway"> -->
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->

 <title> Download App</title>
 </head>
<body>
<div class="main_container">
<div class="item">
<a class="a" href="https://drive.google.com/drive/my-drive">Click here to download the Monitoring App </a>    
</div>
</div>
 <style>
  .m{
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: (100% - 100px);
  margin-top: 10px;
    border:1px solid royalblue;margin-left:auto;margin-right:auto;
  
}

td, th {
    border: 1px solid #466b80;
    text-align: left;
    padding: 8px;

}

tr:nth-child(odd) {
    background-color: royalblue;
}
.main_container{
  width: auto;
  margin-top: 10px;
  margin-left: 200px;
  padding: 15px;
  transition: all 0.3s ease;
}
.main_container .item{
  background: #fff; 
  margin-bottom: 5px;
  padding: 10px;
  font-size: 15px;
  width: 400px;

border:  solid royalblue;
}

</style>
 </body>
</html>
