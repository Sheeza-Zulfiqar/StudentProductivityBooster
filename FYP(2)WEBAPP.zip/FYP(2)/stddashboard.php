<?php 
   session_start();
  include "db_conn.php";
  //  $username=$_SESSION['username']?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title> Navigation Bar</title>

  <link rel="stylesheet" href="styles.css">
	<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
	<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script>
		$(document).ready(function(){
			$(".hamburger").click(function(){
			   $(".wrapper").toggleClass("collapse");
			});
		});
	</script>
</head>
<body>
<?php if ((isset($_SESSION['role'])) == 'student') {?>
<div class="wrapper">
  <div class="top_navbar">
    <div class="hamburger">
       <div class="one"></div>
       <div class="two"></div>
       <div class="three"></div>
    </div>
    <div class="top_menu">
      <div class="logo">Smart Education System</div>
      <ul>
      <li>
          <h3 style ='color: royalblue'>
			    	<?=$_SESSION['username']?>
			    </h3></li>
       
        <li>    
			    <a href="logout.php" class="btn btn-dark">
			  
          <i class="fas fa-user" aria-hidden="true"></i>
          </a></li>
          
      </ul>
    </div>
  </div>
  
  <div class="sidebar">
      <ul>
        <li><a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <span class="icon"><i class="fas fa-book"></i></span>
          <span class="title">Assignments</span></a></li>
        <li><a href="integrate.php">
          <span class="icon"><i class="fas fa-file"></i></span>
          <span class="title">Reports</span>
          </a></li>
        <li><a class="nav-link collapsed" href="getTable.php" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
        <!-- <a href="#time"> -->
          <span class="icon"><i class="fa fa-calendar"></i></span>
          <span class="title">Time Table</span>
          </a></li>
          <li><a class="nav-link collapsed" href="download.php" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
        <!-- <a href="#time"> -->
          <span class="icon"><i class="fa fa-calendar"></i></span>
          <span class="title">Download App</span>
          </a></li>
        
    </ul>
  </div>
  
  <div class="main_container">
    
  </div>
  
  

</div>
<?php }?>

	
</body>
</html>
