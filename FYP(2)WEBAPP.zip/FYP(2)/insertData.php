
<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'fyp');
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$subject=$day=$start_at=$end_at=$subject_err=$day_err=$start_err=$end_err="";
if(isset($_POST['insert']))
{
       // Validate username
    if(empty(trim($_POST["subject"])))
    {
        $subject_err= "*Please enter a subject.";
    } else
    {
        $subject = trim($_POST["subject"]);
    }
    
    // Validate password
    if(empty(trim($_POST["day"])))
    {
        $day_err = "*Please enter a day.";     
    }  else
    {
        $day = trim($_POST["day"]);
    }
   
        // Close statement

    if(empty(trim($_POST["start_at"])))
    {
        $start_err = "*Please enter start time.";     
    }  else
    {
        $start = trim($_POST["start_at"]);
    }
    if(empty(trim($_POST["end_at"])))
    {
        $end_err = "*Please enter a time.";     
    }  else{
        $end = trim($_POST["end_at"]);
    }
   
       
    }

        
        
    
    if(empty($subject_err) && empty($day_err) && empty($start_err) && empty($end_err))
{
        // $param_password = password_hash($password, PASSWORD_DEFAULT); 
     
        $link->query("insert into timtable(subject,day,start_at,end_at) values('$subject','$day','$start_at', '$end_at')");
    if(!$link) 
    { 
      echo mysqli_error(); 
    }
    // else
    // {
    // header("location: index.php");
    // }

}

?>
<script>
function TimeIsValid(){
    var field = document.getElementById('start_at');
    if(field.value.match("/^([0-9]{2,4})-([0-1][0-9])-([0-3][0-9]) (?:([0-2][0-9]):([0-5][0-9]):([0-5][0-9]))?$/")) 
        return true;
}
</script>
<html>
<head>
<title>Insert TimeTable</title>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="style.css">
    <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">-->
    <link href="//cdn.muicss.com/mui-0.10.0/css/mui.min.css" rel="stylesheet" type="text/css" />
    <script src="//cdn.muicss.com/mui-0.10.0/js/mui.min.js"></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<style>
    #btnn
  {
    width:120px;
    margin-left:150px;
    margin-top:4px;
    display: flex;
    align-items: center;
    flex-direction:column;
  }
.wrapper{
  height:auto;
    width:auto;
    justify-content:center;
    background-color: darkcyan;
    /*background-image:url("./images/pic8.jpg");*/
    background-repeat:no-repeat;
    background-size:100%;
    align-items: center;
    display:flex;
    flex-direction:column;
  
  }
  .form-wrapper{
    width:500px;
    height:auto;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  Button a:hover {
  
  color:white;
}
 
  input::placeholder{
    font-family: "Times New Roman", Times, serif;
  }
  h1{
  
    text-align: center;
    width:100%;
    color:blue;
    font-family: "Times New Roman", Times, serif;
    
  }
  
  label{
    font-family: "Times New Roman", Times, serif;
    font-size: 17px;
    font-weight:lighter;
    margin-top:0px;
    margin-bottom: 1px;
    color: #222;
  }
  #head{
    font-family: "Times New Roman", Times, serif;
  }
  input{
    font-family: "Times New Roman", Times, serif;
    padding: 5px 230px 5px 5px;
    margin-bottom: 2px;
    margin-right: 10px;
    border-radius: 5px;
    outline:none;
     
  }
 #errormessage{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:red;

 }
 #errormessage1{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:red;

 }
 #errormessage2{
    font-family: "Times New Roman", Times, serif;
    font-size:15px;
    color:red;

 }
  p{
    font-family: "Times New Roman", Times, serif;
    margin-left:90px;
  }
  /* #regNo{
    padding: 10px 180px 10px 10px;
  } */
  #fix{
      height:48px;
  }
</style>



    <body>
    <div class="conatiner">
       <div class="form-wrapper">
         <h1>Add time table</h1>
       <form  method="post" class= "form-horizontal">
          <div  class="mx-auto <?php echo (!empty($$subject_err)) ? 'has-error' : ''; ?>">
          <label htmlFor="username">Subject:</label>
          <input type="text" placeholder="Subject" id="subject" name="subject" />
          <span id="errormessage1" class="help-block"><?php echo $subject_err; ?></span>
          </div>

          <div  class="mx-auto <?php echo (!empty($day_err)) ? 'has-error' : ''; ?>">
            <label htmlFor="day">Day:</label>
            <!-- <div class="input-group-prepend"> -->
              <input type="text" placeholder="day" id="day" name="day"  />
            <span id="errormessage2"class="help-block"><?php echo $day_err; ?></span>
          </div>
         

          <div class="mx-auto <?php echo (!empty($start_err)) ? 'has-error' : ''; ?>">
          <label htmlFor="start_at">Start at:</label>
          <input type="text" placeholder="start_at" id="start_at"  name="start_at" required onBlur="TimeIsValid()"/>
          <span id="errormessage" class="help-block"><?php echo $start_err; ?></span>
          </div>
         
          <div class="mx-auto <?php echo (!empty($end_err)) ? 'has-error' : ''; ?>" >
          <label htmlFor="end_at">End at:</label>
          <input type="text" placeholder="end_at"  id="end_at"name="end_at"  /> 
          <span id="errormessage"class="help-block"><?php echo $end_err; ?></span>
          </div>

          
          <div>
          <button class="btn btn-outline-primary"  id="btnn" name="insert" ><a >Submit</a></button>
            
          </div>
           
          
        
         </form>  
       </div> 
    </div>
</body>
</html>