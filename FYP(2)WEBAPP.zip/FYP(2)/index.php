<?php 
   session_start();
   if (!isset($_SESSION['username']) && !isset($_SESSION['id'])&& !isset($_SESSION['regNo'])) {   ?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", sans-serif;  font-weight: bold}

body, html {
  height: 100%;
  line-height: 1.8;
}

/* Full height image header */
.bgimg-1 {
  background-position: center;
  background-size: cover;
  color:blue;
  background-image: url("download.jpg");
  min-height: 100%;
}

.w3-bar .w3-button {
  padding: 16px;
}
</style>
<body>


<div class=wrapper>
	  <div class="form-wrapper">
      	<form 
      	      action="php/check-login.php" 
      	      method="post" 
      	      style="width: 450px;">
      	      <h1 class="text-center p-3">LOGIN</h1>
      	      <?php if (isset($_GET['error'])) { ?>
      	      <div class="alert alert-danger" role="alert">
				  <?=$_GET['error']?>
			  </div>
			  <?php } ?>
		  <!-- <div class="mb-3">
		    <label for="username" 
		           class="form-label">User name</label>
		    <input type="text" 
		           class="form-control" 
		           name="username" 
		           id="username">
		  </div> -->
		  <div class="mb-4">
		    <label for="regNo" 
		           class="form-label">RegNo</label>
		    <input type="text" 
		           name="regNo" 
		           class="form-control" 
		           id="regNo">
		  </div>
		  <div class="mb-4">
		    <label for="password" 
		           class="form-label">Password</label>
		    <input type="password" 
		           name="password" 
		           class="form-control" 
		           id="password">
		  </div>
		  
		  <div class="mb-1">
		    <label class="form-label">Select User Type:</label>
		  </div>
		  <select class="form-select mb-3"
		          name="role" 
		          aria-label="Default select example">
			  <option selected value="student">student</option>
			  <option value="admin">admin</option>
		  </select>
		 
		  <button type="submit" 
		          class="btn btn-primary">LOGIN</button>
				  <div>
				  <button 
		          class="btn btn-link"><a href="signup.php">Back</a></button>
				  </div>
		</form>
      </div>
</body>
</html>
<style>

* {
  	box-sizing: border-box;
  	font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
  	font-size: 16px;
  	-webkit-font-smoothing: antialiased;
  	-moz-osx-font-smoothing: grayscale;
}
form{
    
    width:100%;
  }
 
.wrapper{
    height:100vh;
    width:100%;
    justify-content:center;
    background-color: darkcyan;
    /*background-image:url("./images/pic8.jpg");*/
    background-repeat:no-repeat;
    background-size:100%;
    align-items: center;
    display:flex;
    flex-direction:column;
  
  }
  .form-wrapper{
    width:550px;
    height:600px;
    display:flex;
    flex-direction:column;
    padding: 20px 40px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  #btnn
  {
    width:120px;
    margin-left:150px;
    margin-top:10px;
    display: flex;
    align-items: center;
    flex-direction:column;
    text:white;
  }
.login {
  	width: 400px;
  	background-color: #ffffff;
  	box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
  	margin: 100px auto;
}
.login h1 {
  	text-align: center;
  	color: #5b6574;
  	font-size: 24px;
  	padding: 20px 0 20px 0;
  	border-bottom: 1px solid #dee0e4;
}
input::placeholder{
    font-family: "Times New Roman", Times, serif;
  }
  h1{
  
  text-align: center;
  width:100%;
  color:blue;
  font-family: "Times New Roman", Times, serif;
}



</style>
<?php }else{
	header("Location: home.php");
} ?>