<?php  

if (isset($_SESSION['regNo']) && isset($_SESSION['id'])) {
    
    $sql = "SELECT * FROM user where role='student' ORDER BY id ASC";
    $res = mysqli_query($conn, $sql);
}else{
	header("Location: index.php");
} 