<?php
include 'stddashboard.php';
// session_start();
// Change this to your connection info.
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = '';
$DATABASE_NAME = 'fyp';
// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if ( mysqli_connect_errno() ) {
	// If there is an error with the connection, stop the script and display the error.
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}

$result = mysqli_query($con,"SELECT * FROM timetable");
?>
<!DOCTYPE html>
<html>
 <head>
 <!-- <link rel="stylesheet" href="styles.css"> -->
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway"> -->
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->

 <title> Retrieve data</title>
 </head>
<body>
<?php
if (mysqli_num_rows($result) > 0) {
?>
<div class="table-responsive"> 
<div class="main_container">
    <div class="item">
  <table>
  
  <tr>
    <th>Subject</th>
    <th>Day</th>
    <th>Starts at</th>
    <th>End at</th>
    
  </tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
    <td><?php echo $row["subject"]; ?></td>
    <td><?php echo $row["day"]; ?></td>
    <td><?php echo $row["start_at"]; ?></td>
    <td><?php echo $row["end_at"]; ?></td>
</tr>
<?php
$i++;
}
?>

</table>
</div>
</div>
</div>
 <?php
}
else{
    echo "No result found";
}
?>
 <style>
  table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 50%;
    border:1px solid black;margin-left:auto;margin-right:auto;
  
}

td, th {
    border: 1px solid #466b80;
    text-align: left;
    padding: 8px;

}

tr:nth-child(odd) {
    background-color: royalblue;
}
.main_container{
  width: (100% - 100px);
  margin-top: 10px;
  margin-left: 200px;
  padding: 15px;
  transition: all 0.3s ease;
}
.main_container .item{
  /* background: #fff; */
  margin-bottom: 10px;
  padding: 15px;
  font-size: 12px;
line-height: 15px; 
}

</style>
 </body>
</html>
