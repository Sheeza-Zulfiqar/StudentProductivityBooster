<?php
// session_start();
include "admindash.php";
?>
<html>
<title>Report</title>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"> -->
<!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway"> --> 
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
</head>
<body>
 <style>
  table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 50%;
    border:5px solid darkslateblue;margin-left:auto;margin-right:auto;
  
}

td, th {
    border: 1px solid #466b80;
    text-align: left;
    padding: 9px;

}

tr:nth-child(odd) {
    background-color: royalblue;
}
.main_container{
  width: (100% - 100px);
  margin-top: 10px;
  margin-left: 200px;
  padding: 15px;
  transition: all 0.3s ease;
}
.main_container .item{
  /* background: #fff; */
  margin-bottom: 10px;
  padding: 15px;
  font-size: 12px;
line-height: 15px; 
}

</style>
</body>
</html>
<?php
include "db_conn.php";
if (isset($_SESSION['username']) && isset($_SESSION['id']) && isset($_SESSION['regNo'])) { 

$response=array();
$response = file_get_contents('http://sheezazulfiqar.pythonanywhere.com/');
$response = json_decode($response,true);

echo ' <div class="table-responsive"> 
<div class="main_container">
    <div class="item"> <table>
<tr><th>Reg No</th><th>Attendance</th><th>Date</th><th>Dominent Emotion</th><th>Participation</th></tr>';

foreach($response as $item) {
    

    echo '<tr><td>'.$item['RegistrationNo'].'</td><td>'.$item['Attendence'].'</td><td>'.$item['Date'].'</td><td>'.$item['Dominent Emotion'].'</td><td>'.$item['Participation'].'</td></tr>';

}
echo '</table></div></div></div>';

// foreach($response as $listitem) {
//     $memo = $listitem['RegistrationNo'];
//     // echo "<br/>".$memo;
//     if ($_SESSION["regNo"] == $memo){
        
//         print_r($listitem);
//         break;
//     }
// }




}


?>