<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: OPTIONS,GET,POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
$con=mysqli_connect("localhost","root","","fyp");
$response=array();
if ($con){
    $sql='select * from timetable';
    $result=mysqli_query($con,$sql);
    $i=0;
    
    if($result){
       
        header("Content-Type:JSON" );
        while($row=mysqli_fetch_assoc($result))
        {
            $response[$i]['id']=$row ['id'];
            $response[$i]['subject']=$row ['subject'];
            $response[$i]['day']=$row ['day'];
            $response[$i]['start_at']=$row ['start_at'];
            $response[$i]['end_at']=$row ['end_at'];
            $i++;
        }
        echo json_encode($response,JSON_PRETTY_PRINT);
        // echo "Heloo";
    }
    else echo "Nahi ana";

}
else{
    echo "Database not connected";
}
?>