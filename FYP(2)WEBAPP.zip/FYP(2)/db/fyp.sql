-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2021 at 06:11 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fyp`
--

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `day` enum('monday','tuesday','wednesday','thursday','friday','saturday','sunday') DEFAULT NULL,
  `start_at` time DEFAULT NULL,
  `end_at` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`id`, `subject`, `day`, `start_at`, `end_at`) VALUES
(1, 'OOP', 'monday', '08:00:00', '10:00:00'),
(2, 'PF', 'monday', '11:00:00', '12:00:00'),
(3, 'Calculus', 'tuesday', '08:00:00', '10:00:00'),
(4, 'Database', 'tuesday', '01:00:00', '02:00:00'),
(5, 'OOP', 'tuesday', '11:00:00', '12:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `timtable`
--

CREATE TABLE `timtable` (
  `subject` varchar(200) NOT NULL,
  `day` varchar(200) NOT NULL,
  `start_at` time NOT NULL,
  `end_at` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `timtable`
--

INSERT INTO `timtable` (`subject`, `day`, `start_at`, `end_at`) VALUES
('', '', '00:00:00', '00:00:00'),
('', '', '00:00:00', '00:00:00'),
('', '', '00:00:00', '00:00:00'),
('', '', '00:00:00', '00:00:00'),
('', '', '00:00:00', '00:00:00'),
('OOP', 'Monday', '00:00:00', '00:00:00'),
('OOP', 'Monday', '00:00:00', '00:00:00'),
('OOP', 'Tuesday', '00:00:00', '00:00:00'),
('OOP', 'Tuesday', '00:00:00', '00:00:00'),
('OOP', 'Monday', '00:00:00', '00:00:00'),
('oop', 'monday', '00:00:00', '00:00:00'),
('oop', 'monday', '00:00:00', '00:00:00'),
('OOP', 'Monday', '00:00:00', '00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `regNo` varchar(10) NOT NULL,
  `password` varchar(15) NOT NULL,
  `role` enum('student','admin','','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `regNo`, `password`, `role`) VALUES
(1, 'kushf', 'kushf@gmail.com', '2017CS15', 'admin123', 'admin'),
(2, 'Kushf', 'k@gmail.com', '17CS14', 'abcdef', 'student'),
(4, 'Saleha', 'saleha@gmail.com', '12321', 'saleha', 'student'),
(5, 'Ali', 'ali@gmail.com', '12431', 'ali123', 'student'),
(6, 'Amna', 'amna@gmail.com', '17CS12', 'amna123', 'student'),
(7, 'Tooba', 'tooba@gmail.com', '2017cs263', 'tooba123', 'student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `timetable`
--
ALTER TABLE `timetable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
