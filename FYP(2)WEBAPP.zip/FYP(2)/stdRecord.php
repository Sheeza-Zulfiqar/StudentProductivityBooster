<?php
include 'admindash.php';
// session_start();
// Change this to your connection info.
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = '';
$DATABASE_NAME = 'fyp';
// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if ( mysqli_connect_errno() ) {
	// If there is an error with the connection, stop the script and display the error.
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}

$result = mysqli_query($con,"SELECT * FROM user where role='student' ORDER BY id ASC");
?>
<!DOCTYPE html>
<html>
 <head>
 <title> Retrieve data</title>
 </head>
<body>
<?php
if (mysqli_num_rows($result) > 0) {
?>
  <table>
  
  <tr>
  <td>Id</td>
    <td>Email</td>
    <td>Reg No</td>
    <td>Username</td>
    <td>Role</td>
    
  </tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
<td><?php echo $row["id"]; ?></td>
    <td><?php echo $row["email"]; ?></td>
    <td><?php echo $row["regNo"]; ?></td>
    <td><?php echo $row["username"]; ?></td>
    <td><?php echo $row["role"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
 <?php
}
else{
    echo "No result found";
}
?>
<style>
  table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 50%;
    border:5px solid darkslateblue;margin-left:auto;margin-right:auto;
  
}

td, th {
    border: 1px solid #466b80;
    text-align: left;
    padding: 8px;

}

tr:nth-child(odd) {
    background-color: royalblue;
}
.main_container{
  width: (100% - 200px);
  margin-top: 10px;
  margin-left: 200px;
  padding: 10px;
  transition: all 0.3s ease;
}
.main_container .item{
  /* background: #fff; */
  margin-bottom: 10px;
  padding: 15px;
  font-size: 12px;
line-height: 15px; 
}

</style></body>
</html>
