<?php 
   session_start();
   include "db_conn.php";
  //  $username=$_SESSION['username']?>	
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title> Admin Home</title>

  <link rel="stylesheet" href="styles.css">
	<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
	<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script>
		$(document).ready(function(){
			$(".hamburger").click(function(){
			   $(".wrapper").toggleClass("collapse");
			});
		});
	</script>
</head>
<body>

<div class="wrapper">
  <div class="top_navbar">
    <div class="hamburger">
       <div class="one"></div>
       <div class="two"></div>
       <div class="three"></div>
    </div>
    <div class="top_menu">
      <div class="logo">Smart Education System</div>
      <ul>
      <li>
          <h5 style ='color: royalblue'>
			    	<?=$_SESSION['username']?>
                   <div> <?=$_SESSION['role']?></div>
			    </h5></li>
       
        <li>    
			    <a href="logout.php" class="btn btn-dark">
			  
          <i class="fas fa-user" aria-hidden="true"></i>
          </a></li>
          
      </ul>
    </div>
  </div>
  
  <div class="sidebar">
      <ul>
        
        <li><a href="adminReport.php">
          <span class="icon"><i class="fas fa-file"></i></span>
          <span class="title">Reports</span>
          </a></li>
        <li><a class="nav-link collapsed" href="stdRecord.php" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
        <!-- <a href="#time"> -->
          <span class="icon"><i class="fa fa-calendar"></i></span>
          <span class="title">View Students</span>
          </a></li>
        
    </ul>
  </div>
  
  <div class="main_container">
    
  </div>

            </div>
</body>
</html>